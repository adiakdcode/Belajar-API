Project API Rental Mobil 
1. untuk menjalankan web front end pastikan gunakan web server dari VS Code
   >>> https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer
2. gunakan Xammp untuk menjalankan Web API /rest API
3. Sebelum itu pastikan DB sudah diimport

Thanks....