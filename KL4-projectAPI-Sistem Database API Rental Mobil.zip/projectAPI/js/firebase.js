var firebaseConfig = {
    apiKey: "AIzaSyAw9AHb835fPCMgeAbjmr0psRC8nTCzheE",
    authDomain: "petek0.firebaseapp.com",
    projectId: "petek0",
    storageBucket: "petek0.appspot.com",
    messagingSenderId: "659918420959",
    appId: "1:659918420959:web:f5e80fa00c3332c691626a",
    measurementId: "G-18YJ8P36DE"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();
    
    

