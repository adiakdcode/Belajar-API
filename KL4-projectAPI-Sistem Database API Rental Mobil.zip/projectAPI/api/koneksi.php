<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "rentalmobil";

$db=mysqli_connect($server, $username, $password, $database);
?>